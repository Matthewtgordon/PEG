# `LiteLLM Model`

::: agents.extensions.models.litellm_model
