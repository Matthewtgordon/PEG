# `Audio Formats`

::: agents.realtime.audio_formats
