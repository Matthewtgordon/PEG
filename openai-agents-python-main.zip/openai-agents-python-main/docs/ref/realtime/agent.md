# `RealtimeAgent`

::: agents.realtime.agent.RealtimeAgent