# `Openai Realtime`

::: agents.realtime.openai_realtime
