# `Chatcmpl Stream Handler`

::: agents.models.chatcmpl_stream_handler
